### This is my collection of scripts that I have collected from vatoius sources such as coding forums,stackoverflow, reddit.If you free to contibute,let me know.
