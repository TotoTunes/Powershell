# PS-DSC-Course
Course material for one day course on PowerShell DSC
